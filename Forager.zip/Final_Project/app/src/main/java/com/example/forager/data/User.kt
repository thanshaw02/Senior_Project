package com.example.forager.data

data class User(
    val userName: String? = null,
    val fullName: String? = null,
    var email: String? = null,
)