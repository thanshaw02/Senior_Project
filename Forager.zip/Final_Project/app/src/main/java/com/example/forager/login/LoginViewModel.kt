package com.example.forager.login

import androidx.lifecycle.ViewModel

class LoginViewModel : ViewModel() {



}