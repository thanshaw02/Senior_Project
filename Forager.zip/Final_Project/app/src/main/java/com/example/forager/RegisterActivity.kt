package com.example.forager

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.util.Log
import android.widget.EditText
import android.widget.Toast
import com.example.forager.data.User
import com.example.forager.databinding.ActivityRegisterBinding
import com.example.forager.login.INTENT_MESSAGE
import com.example.forager.login.LoginActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase

/******************************************************************************************************************************************************
 *  TODO: Also, need to figure out a way to finish this activity after registering/going back to the log in page (right now the activity stays alive) *
*******************************************************************************************************************************************************/

private const val TAG = "RegisterActivity:"

class RegisterActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRegisterBinding
    private lateinit var database: DatabaseReference
    private lateinit var auth: FirebaseAuth
    private lateinit var newUser: User

    // Register fields
    private lateinit var fullNameET: EditText
    private lateinit var usernameET: EditText
    private lateinit var emailET: EditText
    private lateinit var passwordET: EditText


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Initializing fields
        fullNameET = binding.firstNameET
        usernameET = binding.usernameET
        emailET = binding.emailET
        passwordET = binding.passwordET

        // Initializing database
        database = Firebase.database.reference

        auth = Firebase.auth

        // Check to see if the password is at least 6 characters long!!
        binding.registerBtn.setOnClickListener {
            if((fullNameET.text.isNotEmpty() && usernameET.text.isNotEmpty()) && (emailET.text.isNotEmpty() && passwordET.text.isNotEmpty()))
                registerNewUser(
                    usernameET.text.toString(),
                    fullNameET.text.toString(),
                    binding.emailET.text.toString(),
                    binding.passwordET.text.toString())
            else
                Toast.makeText(this, "Please fill out all of the fields.", Toast.LENGTH_SHORT).show()
        }

        // Need to close this activity, otherwise it will still be running in the background until the app is fully closed
        binding.textView12.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            finish()
            // try to close this activity for good, maybe??
        }

        binding.showPassword.setOnClickListener {
            if(passwordET.transformationMethod.equals(PasswordTransformationMethod.getInstance())) {
                // Show password
                passwordET.transformationMethod = HideReturnsTransformationMethod.getInstance()
            }
            else {
                // Hide password
                passwordET.transformationMethod = PasswordTransformationMethod.getInstance()
            }
        }
    }

    private fun registerNewUser(username: String, firstName: String, email: String, password: String) {
        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if(task.isSuccessful) {
                    // User was created successfully and also has been signed in
                    Log.d(TAG, "createUserWithEmail:success")
                    val user = auth.currentUser
                    writeNewUser(user!!.uid, username, firstName, email)
                    goToHomeScreen(user)
                    finish()
                }
                else {
                    // If user account could not be created
                    Log.w(TAG, "createUserWithEmail:failure", task.exception)
                    Toast.makeText(baseContext, "Authentication failed.", Toast.LENGTH_SHORT).show()
                    //goToHomeScreen(null)
                }
            }
    }

    private fun writeNewUser(userID: String, username: String, firstName: String, email: String) {
        newUser = User(username, firstName, email)
        database.child("Users").child(userID).setValue(newUser)
    }

    // Come back to this, try to consolidate code into one place instead of throwing it everywhere
    private fun goToHomeScreen(user: FirebaseUser) {
        val intent = Intent(this, MapsActivity::class.java).apply {
            putExtra(INTENT_MESSAGE, user)
        }
        //Log.d(TAG, "User metadata: ${user.metadata}")
        startActivity(intent)
    }

    // If for whatever reason the user is on this activity and is logged in, this will bring them to the home page
    override fun onStart() {
        super.onStart()
        val currentUser = auth.currentUser
        if(currentUser != null) {
            goToHomeScreen(currentUser)
        }
    }
}