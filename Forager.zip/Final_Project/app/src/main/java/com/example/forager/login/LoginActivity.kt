package com.example.forager.login

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.util.Log
import android.widget.ImageButton
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import com.example.forager.MapsActivity
import com.example.forager.R
import com.example.forager.RegisterActivity
import com.example.forager.databinding.ActivityLoginBinding
import com.facebook.CallbackManager
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.common.api.GoogleApiClient
import com.google.firebase.FirebaseApp
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.analytics.FirebaseAnalytics.Event.LOGIN
import com.google.firebase.analytics.ktx.analytics
import com.google.firebase.analytics.ktx.logEvent
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.appcheck.debug.DebugAppCheckProviderFactory
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import com.google.firebase.ktx.initialize

/*************************************************************************************************************************************************
 *  TODO: declare all widget and initialize them, makes my code cleaner and easier to read
 *  TODO: My show_password image-button is not positioned correctly, need to figure out how to deal with this
 *  TODO: Add a sort of "splash screen", this will load firs  t and then after 2 or 3 seconds bring the user to the loginActivity or mapsActivity
 *  TODO: Google login does not currently work, come back to this
 **************************************************************************************************************************************************/

private const val TAG = "LoginActivity"
const val INTENT_MESSAGE = "com.example.forager.SUCCESSFUL_LOGIN"
private const val RC_SIGN_IN = 120

class LoginActivity : AppCompatActivity() {

    // Firebase authentication instance
    private lateinit var auth: FirebaseAuth
    private lateinit var callBackManager: CallbackManager

    // Google sign-in variables
    private lateinit var gso: GoogleSignInOptions
    private lateinit var googleSignInClient: GoogleSignInClient

    // Firebase analytics instance
    private lateinit var firebaseAnalytics: FirebaseAnalytics

    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // This bit of code is used to get my debug token for Firebase
//        FirebaseApp.initializeApp(this)
//        val firebaseAppCheck = FirebaseAppCheck.getInstance()
//        firebaseAppCheck.installAppCheckProviderFactory(
//            DebugAppCheckProviderFactory.getInstance()
//        )

        gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(getString(R.string.google_web_client_id))
            .requestEmail()
            .build()
        googleSignInClient = GoogleSignIn.getClient(this, gso)

        // Initializing my FirebaseAuth variable
        auth = Firebase.auth

        firebaseAnalytics = Firebase.analytics

        binding.loginBtn.setOnClickListener {
            if(binding.editTextTextEmailAddress.text.toString() != "" && binding.editTextTextPassword.text.toString() != "") {
                signInWithEmail(binding.editTextTextEmailAddress.text.toString(), binding.editTextTextPassword.text.toString(), savedInstanceState)
            }
        }

        binding.createAccount.setOnClickListener {
            val intent = Intent(this, RegisterActivity::class.java)
            startActivity(intent)
        }

        // Come back to this, setting up Facebook login
        binding.loginFacebook.setOnClickListener {
            // This will not work, come back in a couple weeks
        }

        // Signing in via google auth
        binding.loginGoogle.setOnClickListener {
            // This will not work, come back in a couple weeks
        }

        binding.showPassword.setOnClickListener {
            if(binding.editTextTextPassword.transformationMethod.equals(PasswordTransformationMethod.getInstance())) {
                // Show password
                binding.editTextTextPassword.transformationMethod = HideReturnsTransformationMethod.getInstance()
            }
            else {
                // Hide password
                binding.editTextTextPassword.transformationMethod = PasswordTransformationMethod.getInstance()
            }
        }
    }

    private fun signInWithFacebook() {


    }

    // Attempts to login the user with the given information
    private fun signInWithEmail(email: String, password: String, bundle: Bundle?) {
        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if(task.isSuccessful) {
                    // Updates the UI here
                    // Moves the user to the map portion of the app with their account information
                    Log.d(TAG, "signedInWithEmail:success")
                    firebaseAnalytics.logEvent(LOGIN, bundle)
                    val user = auth.currentUser
                    goToHomeScreen(user!!)
                }
                else {
                    // Sign in failed, entered wrong information
                    Log.w(TAG, "signedInWithEmail:failure", task.exception)
                    Toast.makeText(this, "Authentication failed.", Toast.LENGTH_SHORT).show()
                }
            }
    }

    private fun goToHomeScreen(user: FirebaseUser) {
        val intent = Intent(this, MapsActivity::class.java).apply {
            putExtra(INTENT_MESSAGE, user)
        }
        //Log.d(TAG, "User metadata: ${user.metadata}")
        startActivity(intent)
    }

    override fun onStart() {
        super.onStart()
        // Checking to see if user has signed in or not (if a user has signed in then 'current' user will be non-null)
        val currentUser = auth.currentUser
        // Check if someone has already signed in with Google OR Facebook
        if((currentUser != null)) {
            // Then change to a different view, which will probably be the maps view
            goToHomeScreen(currentUser)
            // Need to add the googleUser here to pass to the main map activity
        }
    }
}