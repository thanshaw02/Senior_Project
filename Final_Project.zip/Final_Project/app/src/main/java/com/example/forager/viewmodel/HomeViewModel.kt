/**
 * - LiveData here that gets the data from the DataRepository
 * - That then gets the data from the DB's
 */

package com.example.forager.viewmodel

import android.content.Context
import android.util.Log
import androidx.lifecycle.*
import com.example.forager.localdata.model.Plant
import com.example.forager.remotedata.PlantListNode
import com.example.forager.remotedata.User
import com.example.forager.repository.DataRepository
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.FirebaseDatabase

private const val LOG = "HomeViewModel"

class HomeViewModel : ViewModel() {

    /**
     *                      CODE BELOW IS WORKING AS INTENDED
     */

    /**
     *                          Local Data Operations
     */

    val getLocalPlantData: MutableList<Plant> get() = DataRepository.getLocalPlantData

    // Initializing local data
    fun localDataInit(context: Context) {
        DataRepository.getLocalPlantData(context)
    }

    /**
     *                           Remote Data Operations
     */

    /****************************************************************************************************************************************************/
    fun addPlantToDB(latLng: LatLng, plantToAdd: Plant, plantNotes: String) {
        DataRepository.addPlantLocation(latLng, plantToAdd, plantNotes)
    }

    fun findPlantNode(plantName: String): Plant? {
        return DataRepository.findPlantNode(plantName)
    }
    /****************************************************************************************************************************************************/

    /****************************************************************************************************************************************************/
    // This works, but doesn't look great
    // Keep for now, but if I have time come back and optimize this
    private var databaseHolder = FirebaseDatabase.getInstance()
    fun deleteUserAccount(email: String, password: String, user: FirebaseUser) {
        user.reauthenticate(EmailAuthProvider.getCredential(email, password)).addOnCompleteListener {
            if(it.isSuccessful) {
                Log.d(LOG, "User was re-authenticated")
                DataRepository.deleteUserFromDB(user, databaseHolder.reference)
                //DataRepository.signOut()
                DataRepository.deleteUserAuth(user)
            }
            else Log.d(LOG, "User was not re-authenticated")
        }
    }
    /****************************************************************************************************************************************************/

    /****************************************************************************************************************************************************/
    // This works, but is a very crude way of passing the "numOfPlants" variable around
    fun getUsersPlantFoundDataInit() { DataRepository.getUsersPlantFoundData() }
    private fun transformIncomingString(snapshot: DataSnapshot): LiveData<String> {
        return MutableLiveData(snapshot.value.toString())
    }
    private val transformNumPlantsFound: LiveData<String> = Transformations.switchMap(DataRepository.getTestingNumPlantsFoundGet) {
        transformIncomingString(it)
    }
    val getTheNumOfPlants: LiveData<String> get() = transformNumPlantsFound
    fun incrementPlantsFound(increment: Int) {
        DataRepository.incrementPlantsFound(increment + 1)
    }
    /****************************************************************************************************************************************************/

    /****************************************************************************************************************************************************/

    // These 15 lines of code load the logged in user's data from DataRepository when they first log in
    fun getUserDataInit() { DataRepository.getTheUserFromFirebase() }
    private fun transformCurrentUserSnapshot(userDS: DataSnapshot): LiveData<User> {
        return MutableLiveData(
            User(
                userDS.child("userName").value.toString(),
                userDS.child("fullName").value.toString(),
                userDS.child("email").value.toString(),
                userDS.child("dateCreated").value.toString(),
                userDS.child("numPlantsFound").value.toString()
            ))
    }
    private val userLiveData: LiveData<User> = Transformations.switchMap(DataRepository.getUser) { userDS ->
        // Log.d(LOG, "The user's data has been loaded in DataRepository, and now is loading into HomeViewModel: $userDS")
        transformCurrentUserSnapshot(userDS)
    }
    val getUserLiveData: LiveData<User> get() = userLiveData

    private var firstTimeClicking = true
    val getFirstTimeClicking get() = firstTimeClicking
    fun setFirstTimeClick(set: Boolean) {
        firstTimeClicking = set
    }
    /****************************************************************************************************************************************************/

    /****************************************************************************************************************************************************/

                                /* Handling the toggling of markers */
/***************************************************************************************************/
    // Holds the state of the marker toggle
    private var hasBeenToggled = true // True is toggled on, false is toggle of
    val getHasBeenToggled get() = hasBeenToggled
    fun setHasBeenToggled(toggle: Boolean) {
        hasBeenToggled = toggle
    }

    var addedPreviousMarks = false

    // This gets the user's list of plants found and re-creates the markers on the map
    private val plantsFoundMarkers: MutableList<Marker> = mutableListOf()
    val getPlantsFoundMarkers get() = plantsFoundMarkers

    fun addMarker(marker: Marker) {
        plantsFoundMarkers.add(marker)
        Log.d(LOG, "List of markers size: ${getPlantsFoundMarkers.size}")
    }

    fun clearMarkers() { plantsFoundMarkers.clear() }

    fun toggleMarkers(toggled: Boolean) {
        Log.d(LOG, "List of markers size: ${plantsFoundMarkers.size}")
        var count = 0
        plantsFoundMarkers.forEach { marker ->
            Log.d(LOG, "Marker #${count++}: ${marker.title}")
            marker.isVisible = toggled
        }
    }

/***************************************************************************************************/

fun getPersonalPlantListOfUserInit() { DataRepository.getPersonalPlantListOfUser() }
    private fun transformPersonalListOfUser(list: MutableList<DataSnapshot>): LiveData<MutableList<PlantListNode>> {
        val tempListOfUsersPlants: MutableList<PlantListNode> = mutableListOf()
        list.forEach { value ->
            tempListOfUsersPlants.add(
                PlantListNode(
                    value.child("lat").value.toString().toDouble(),
                    value.child("long").value.toString().toDouble(),
                    Plant(
                        value.child("plantAdded").child("commonName").value.toString(),
                        value.child("plantAdded").child("scientificName").value.toString(),
                        value.child("plantAdded").child("plantType").value.toString().toInt(),
                        value.child("plantAdded").child("plantColor").value.toString(),
                        value.child("plantAdded").child("sun").value.toString(),
                        value.child("plantAdded").child("height").value.toString()
                    ),
                    value.child("plantNotes").value.toString()
                )
            )
        }
        return MutableLiveData(tempListOfUsersPlants)
    }
    private val personalPlantListOfUser: LiveData<MutableList<PlantListNode>> = Transformations.switchMap(DataRepository.getPersonalPlantListOfUser) {
        Log.d(LOG, "User's list is being updated..")
        transformPersonalListOfUser(it)
    }
    val getPersonalPlantListOfUsers: LiveData<MutableList<PlantListNode>> get() = personalPlantListOfUser

    // Getting the user's first name
    val getUsersFullName get() = DataRepository.getUsersFullName()

    // this will clear the markers from whoever was logged in previously
    private fun clearOldListData() {
        DataRepository.clearOldListData()
        clearMarkers()
    }

    /****************************************************************************************************************************************************/

    /****************************************************************************************************************************************************/

    fun logout() {
        clearOldListData()
        setHasBeenToggled(false)
        DataRepository.signOut()
    }

    /****************************************************************************************************************************************************/

    /****************************************************************************************************************************************************/

    /**
     *  Utility functions, moved from my View's to my ViewModel to further strip down the logic in my View's
     */

    // Checks the lengths of both the common and scientific names of each plant
    // Shortens the scientific names down depending on how long they are
    fun checkNameLengths(plant: Plant): String {
        if(plant.commonName.length > 19 && plant.scientificName.length > 20) {
            var shortenedScientificName = ""
            for(letter in 0..10) shortenedScientificName += plant.scientificName[letter]
            return "$shortenedScientificName..."
        }
        return plant.scientificName
    }

    // This translate the type of each from, plant types are represented as integers in my database
    fun getPlantType(plantType: Int): String {
        return when(plantType) {
            0 -> "Wildflower"
            1 -> "Fern"
            2 -> "Tree/Shrub/Vine"
            3 -> "Grasses/Sedges/Rushes"
            else -> "Unknown"
        }
    }

    /****************************************************************************************************************************************************/

    /****************************************************************************************************************************************************/

}