package com.example.forager.testing.repository

class TestRepository {
}