package com.example.forager.testing.viewmodel

class TestViewModel {
}