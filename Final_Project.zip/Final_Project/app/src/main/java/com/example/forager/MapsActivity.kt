/**
 *  TODO: Color theme: https://material.io/resources/color/#!/?view.left=0&view.right=1&primary.color=aade9a&secondary.color=37a187
 *  TODO: Also, I need to start migrating everything over to my "HomeViewModel" like the two PlantLists
 *  TODO: Also need to remove the PlantListsAc
 */

package com.example.forager

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.Gravity
import android.view.View
import android.widget.TextView
import android.widget.Toast
import android.widget.Toolbar
import androidx.activity.viewModels
import androidx.annotation.IdRes
import androidx.appcompat.app.AlertDialog
import androidx.core.view.GravityCompat
import androidx.core.view.WindowCompat
import androidx.core.view.isVisible
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Observer
import androidx.navigation.*
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.NavigationUI
import androidx.navigation.ui.NavigationUI.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.example.forager.databinding.ActivityMapsBinding
import com.example.forager.fragments.*
import com.example.forager.oldcode.misc.CameraAndViewport
import com.example.forager.oldcode.misc.TypeAndStyles
import com.example.forager.remotedata.User
import com.example.forager.repository.login.LoginActivity
import com.google.firebase.auth.FirebaseAuth
import com.example.forager.repository.LOG_OFF
import com.example.forager.viewmodel.HomeViewModel
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.navigation.NavigationView
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.switchmaterial.SwitchMaterial
import java.lang.Exception

private const val LOG = "MapsActivityDEBUG"

class MapsActivity :  AppCompatActivity() {

    // Navigation host and controller
    private val navHostFragment by lazy {
        supportFragmentManager.findFragmentById(R.id.fragment_container) as NavHostFragment
    }

    private lateinit var navController: NavController

    // Bottom meny class helper instance
//    private lateinit var bottomNavMenu: BottomNavigationView
    private lateinit var binding: ActivityMapsBinding
    private lateinit var toggleMarkerBtn: SwitchMaterial

    // Menu widgets
    private lateinit var menuBtn: MaterialToolbar
    private lateinit var menuLayout: DrawerLayout
    private lateinit var menuNavView: NavigationView

    // Creating an instance of FriebaseAuth which will hold on to whoever has logged in
    private lateinit var auth: FirebaseAuth
    private lateinit var currentUser: User
    private lateinit var numPlantsFound: String

    // GoogleMapsAPI variables
    //lateinit var map: GoogleMap
    private val typeAndStyles by lazy { TypeAndStyles() } // This is what I'm using for the style of my map!
    private val  cameraAndViewport by lazy { CameraAndViewport() }
    private val grav by lazy { Gravity() }

    // ViewModel
    private val homeVM by viewModels<HomeViewModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Initializing navController
        navController = navHostFragment.navController

        // Menu drawer logic
        menuLayout = binding.drawerLayout
        menuNavView = binding.myNavigationView

        WindowCompat.setDecorFitsSystemWindows(window, false)

        homeVM.getPersonalPlantListOfUserInit() // Initializing the user's personal plant list
        homeVM.getUserDataInit() // This will get the user's data as it is when they first log in, hopefully??
        homeVM.localDataInit(this) // Initializing local data (mainly for the auto-complete feature)

        auth = FirebaseAuth.getInstance()
        //bottomNavMenu = binding.bottomNav
        toggleMarkerBtn = binding.toggleMarkers

        // Setting up menu with nav graph
        setupDrawerLayout()

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
//        val mapFragment = supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
//        mapFragment.getMapAsync(this)

        homeVM.getTheNumOfPlants.observe(this, object: Observer<String> {
            override fun onChanged(incoming: String?) {
                numPlantsFound = incoming!!
            }
        })

        // This is working as intended --> KEEP FOR NOW
        homeVM.getUserLiveData.observe(this, object: Observer<User> {
            override fun onChanged(loadedUser: User?) {
                Log.d(LOG, "A user has been loaded in..")
                try {
                    currentUser = loadedUser!!
                    numPlantsFound = currentUser.numPlantsFound
                    Log.d(LOG, "Number of plants found: $numPlantsFound")
                } catch (e: Exception) {
                    Log.d(LOG, "There was an exception loading the user: $e")
                }
            }
        })

//        menuBtn.setNavigationOnClickListener {
//            val menuHeaderPlantsFound = findViewById<TextView>(R.id.user_plants_found)
//            if(homeVM.getFirstTimeClicking) {
//                // This may throw a "NullPointerException" ERROR!!
//                // Load the user's data into the menu profile section
//                val menuHeaderFullName = findViewById<TextView>(R.id.user_full_name)
//                val menuHeaderUserName = findViewById<TextView>(R.id.user_username)
//                menuHeaderFullName.text = currentUser.fullName
//                menuHeaderUserName.text = currentUser.userName
//                menuHeaderPlantsFound.text = currentUser.numPlantsFound
//
//                homeVM.setFirstTimeClick(false)
//            }
//            else {
//                menuHeaderPlantsFound.text = numPlantsFound
//            }
//            menuLayout.openDrawer(GravityCompat.START) // Opens the menu when pressed
//        }
//
//        menuNavView.setNavigationItemSelectedListener { menuItem ->
//            menuLayout.closeDrawer(GravityCompat.START)
////            goToMenuItem(menuItem.itemId)
//            true
//        }

    }



    // Connecting menu to navigation graph
    private fun setupDrawerLayout() {
        menuNavView.setupWithNavController(navController)
        setupActionBarWithNavController(this, navController, menuLayout)
    }

    override fun onSupportNavigateUp(): Boolean {
        return NavigationUI.navigateUp(navController, menuLayout)
    }

    override fun onBackPressed() {
        if(binding.drawerLayout.isDrawerOpen(GravityCompat.START)) {
            binding.drawerLayout.closeDrawer(GravityCompat.START)
        }
        else super.onBackPressed()
    }



    private fun changeToggleVisibility(toggle: Boolean) {
        Handler().postDelayed({
            // Possibly add an animation here when hiding/displaying the marker toggle
            toggleMarkerBtn.isVisible = toggle
        }, 250)
    }

    // Utility function for menu
    // This functions take the ID of the menu item selected, and opens the fragment associated with that id!
//    private fun goToMenuItem(menuId: Int) {
//        val destinationID = navController.currentDestination!!.id
//        when(menuId) {
//            R.id.homeFragment -> {
//                // Need to find a better way to go back to the home screen, closing fragments until I'm back is sloppy
//                val removeFrag = supportFragmentManager.findFragmentById(R.id.fragment_container)
//                if(removeFrag != null) {
//                    supportFragmentManager
//                        .beginTransaction()
//                        .remove(removeFrag)
//                        .commit()
//                    Handler().postDelayed({
//                        // Possibly add an animation here when hiding/displaying the marker toggle
//                        toggleMarkerBtn.isVisible = true
//                    }, 250)
//                }
//            }
//            R.id.groupsFragment -> {
//                // Work in progress!
//            }
//            R.id.profileFragment -> {
//
//                when(destinationID) {
//                    R.id.mapsFragment -> {
//                        val action = MapsFragmentDirections.navigateToProfileMenu()
//                        navController.navigate(action)
//                        changeToggleVisibility(true)
//                    }
//                    R.id.foundPlantFormFragment -> {
//                        val action = FoundPlantFormFragmentDirections.actionFoundPlantFormFragmentToFragmentProfileMenu()
//                        navController.navigate(action)
//                        changeToggleVisibility(false)
//                    }
//                    R.id.personalPlantListFragment -> {
//                        val action = PersonalPlantListFragmentDirections.actionPersonalPlantListFragmentToFragmentProfileMenu()
//                        navController.navigate(action)
//                        changeToggleVisibility(false)
//                    }
//                    R.id.plantDatabaseFragment -> {
//                        val action = PlantDatabaseFragmentDirections.actionPlantDatabaseFragmentToFragmentProfileMenu()
//                        navController.navigate(action)
//                        changeToggleVisibility(false)
//                    }
//                }
//
//                // Also, if I end up adding these each time to the fragment back-stack I could check to see if this fragment is in the back-stack via its tag
//                // If it is in the back-stack I can navigate back to it??
////                val profileFragment = supportFragmentManager.findFragmentByTag("profile_fragment")
////                if(profileFragment == null) {
////                    val fragmentRoAdd = FragmentProfileMenu.newInstance(currentUser, numPlantsFound)
////                    supportFragmentManager
////                        .beginTransaction()
////                        .add(R.id.fragment_container, fragmentRoAdd, "profile_fragment")
////                        .addToBackStack("profile_fragment")
////                        .commit()
////                }
////                else {
////                    supportFragmentManager
////                        .beginTransaction()
////
////                }
//
////                val currentFragment = supportFragmentManager.findFragmentById(R.id.fragment_container)
////                if(currentFragment?.tag != "profile_fragment") {
////                    val profileFragment = FragmentProfileMenu.newInstance(currentUser, numPlantsFound)
////                    supportFragmentManager
////                        .beginTransaction()
////                        .replace(R.id.fragment_container, profileFragment, "profile_fragment")
////                        .setReorderingAllowed(true)
////                        .commit()
//
////                }
//            }
//            R.id.plantsFragment -> {
//
//
//                // Also, if I end up adding these each time to the fragment back-stack I could check to see if this fragment is in the back-stack via its tag
//                // If it is in the back-stack I can navigate back to it??
////                val currentFragment = supportFragmentManager.findFragmentById(R.id.fragment_container)
////                if(currentFragment?.tag != "my_plants_fragment") {
////                    val myPlantsFragment = PersonalPlantListFragment.newInstance()
////                    supportFragmentManager
////                        .beginTransaction()
////                        .replace(R.id.fragment_container, myPlantsFragment, "my_plants_fragment")
////                        .setReorderingAllowed(true)
////                        .commit()
////                    Handler().postDelayed({
////                        // Possibly add an animation here when hiding/displaying the marker toggle
////                        toggleMarkerBtn.isVisible = false
////                    }, 250)
////                }
//            }
//            R.id.localPlantsFragment -> {
//                val fragmentToAdd = PlantDatabaseFragment.newInstance()
//                supportFragmentManager
//                    .beginTransaction()
//                    .add(R.id.fragment_container, fragmentToAdd, "search_plants_fragment")
//                    .addToBackStack("search_plants_fragment")
//                    .commit()
//                // Also, if I end up adding these each time to the fragment back-stack I could check to see if this fragment is in the back-stack via its tag
//                // If it is in the back-stack I can navigate back to it??
////                val currentFragment = supportFragmentManager.findFragmentById(R.id.fragment_container)
////                if(currentFragment?.tag != "search_plants_fragment") {
////                    val myPlantsFragment = PlantDatabaseFragment.newInstance()
////                    supportFragmentManager
////                        .beginTransaction()
////                        .replace(R.id.fragment_container, myPlantsFragment, "search_plants_fragment")
////                        .setReorderingAllowed(true)
////                        .commit()
////                    Handler().postDelayed({
////                        // Possibly add an animation here when hiding/displaying the marker toggle
////                        toggleMarkerBtn.isVisible = false
////                    }, 250)
////                }
//            }
//            R.id.log_out ->  { logOut() }
//            else -> Toast.makeText(this, "Something went wrong..", Toast.LENGTH_SHORT).show()
//        }
//    }

    // All actions related to Google Maps is done in this function
//    override fun onMapReady(googleMap: GoogleMap) {
//        map = googleMap
//
//        map.setPadding(0, 0, 0, 100)
//
//        toggleMarkerBtn.setOnCheckedChangeListener { compoundButton, toggled ->
//            homeVM.toggleMarkers(toggled)
//        }
//
//        homeVM.getPlantsFoundMarkers.forEach { marker ->
//            val pos = marker.position
//            val title = marker.title
//            map.addMarker(MarkerOptions().position(pos).title(title))
//        }
//
//        // This does NOT work
//        // I need to allow all of the user's found plants to be loaded onto the map when they log in
//        // Right now it works, but only for the first 1-2 logins, after that all data is lost
//        homeVM.getPersonalPlantListOfUsers.observe(this, { plantFoundList ->
//            if(homeVM.getHasBeenToggled) {
//                plantFoundList.forEach { plantNode ->
//                    Log.i(LOG, plantNode.plantAdded.commonName)
//                    val coord = LatLng(plantNode.lat, plantNode.long)
//                    val marker = map.addMarker(MarkerOptions().position(coord).title(plantNode.plantAdded.commonName))
//                    homeVM.addMarker(marker!!)
//                }
//                homeVM.setHasBeenToggled(false)
//            }
//        })
//
//        // Setting the styling of GoogleMap
//        map.uiSettings.apply {
//            isZoomControlsEnabled = true
//        }
//        typeAndStyles.setMapStyle(map, this) // Sets the style of my map using raw JSON
//
//        // Possibly have a button that hides markers, or hides only some markers, etc.
//        map.setOnMapLongClickListener { latlng ->
//            val fragment = FoundPlantFormFragment.newInstance(latlng.latitude, latlng.longitude, numPlantsFound.toInt())
//            supportFragmentManager
//                .beginTransaction()
//                .add(R.id.fragment_container, fragment, "found_plant_ui")
//                .commit()
//        }
//
//        // Add a marker in Sydney and move the camera
//        val marquette = LatLng(46.5436, -87.3954)
//        val newYork = LatLng(40.71614203933524, -74.0040676650565)
//        map.addMarker(MarkerOptions().position(marquette).title("Marquette Marker")) // assigning this marker to a variable so we can change the markers settings
//        map.moveCamera(CameraUpdateFactory.newLatLngZoom(marquette, 10f))
//        //map.moveCamera(CameraUpdateFactory.newCameraPosition(cameraAndViewport.marquette))
//    }

    // trying to initialize the user's data by loading it in when onStart() is called
    override fun onStart() {
        Log.d(LOG, "onStart() called")
        super.onStart()
    }

    // I don't think I need to send an intent to my login page
    // I also don't need to receive and intent, because FirebaseAuth will hold the current user that's already signed in
    private fun logOut() {
        homeVM.logout()
        goToLogin()
    }

    companion object {
        lateinit var map: GoogleMap
        fun newInstance(context: Context): Intent {
            return Intent(context, MapsActivity::class.java)
        }
    }

    private fun goToLogin() {
        viewModelStore.clear() // This is supposed to clear all data held in my HomeViewModel
        val intent = Intent(this, LoginActivity::class.java)
        //intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP); // This destroys all other activities
        startActivity(intent)
    }

    // Using this to reset data in my HomeViewModel
    // then have my HomeViewModel talk to my DataRepository if needed
    override fun onDestroy() {
        super.onDestroy()
        Log.d(LOG, "onDestroy() called")
    }

    override fun onResume() {
        super.onResume()
        Log.d(LOG, "onResume() called")

        // Checking to see if there is a current user (if someone is logged in)
        if(auth.currentUser == null) {
            goToLogin()
        }
    }

    override fun onPause() {
        super.onPause()
        Log.d(LOG, "onPause() called")
    }

    override fun onStop() {
        super.onStop()
        Log.d(LOG, "onStop() called")
    }
}

/*


lifecycleScope.launch {
            delay(4000L)
            marquetteMarker.remove()
        }



        onMapClicked()
        onMapLongClicked()

private fun onMapClicked() {
        map.setOnMapClickListener {
            val latLong = it.latitude.toString() + ", " + it.longitude.toString()
            val toast = Toast.makeText(this@MapsActivity, "Short click on: $latLong", Toast.LENGTH_SHORT)
            toast.setGravity(Gravity.TOP, 50, 50)
            toast.show()
        }
    }

    private fun onMapLongClicked() {
        map.setOnMapLongClickListener {
            map.addMarker(MarkerOptions().position(it).title("Your new marker!"))
            val toast = Toast.makeText(this@MapsActivity, "New marker at: ${it.longitude}, ${it.longitude}", Toast.LENGTH_SHORT)
            toast.setGravity(Gravity.TOP, 50, 50)
            toast.show()

        }
    }


map.uiSettings.apply {
    isZoomControlsEnabled = true
    // I think I want this enabled, need to come back to this
    // I'll first need to enable my-location layer
    // isMyLocationButtonEnabled = true
}
typeAndStyles.setMapStyle(map, this)

lifecycleScope.launch {
    delay(4000L)

    // animates the zooming in OR out depending on the zoom value given (between 0..20)
    //map.animateCamera(CameraUpdateFactory.zoomTo(15f), 2000, null)

    // This will animate the moving of the camera to a specified location in pixels, with a given duration and a GoogleMap.CancelableCallback
    //map.animateCamera(CameraUpdateFactory.scrollBy(200f, 0f), 2000, null)

    // This animates all of the properties from cameraAndViewport.marquette in CameraAndViewport.kt
    // In this final version I use a GoogleMaps.CancelableCallback as the callback, I override two functions "onFinish()" and "onCancel()" and display a Toast message
    map.animateCamera(CameraUpdateFactory.newCameraPosition(cameraAndViewport.melbourne), 2000, object: GoogleMap.CancelableCallback {

        // Toast text will display when the camera animation is finished
        override fun onFinish() {
            Toast.makeText(this@MapsActivity, "Finished", Toast.LENGTH_SHORT).show()
        }

        // Toast text will display when/if the camera animation is canceled
        override fun onCancel() {
            Toast.makeText(this@MapsActivity, "Canceled", Toast.LENGTH_SHORT).show()
        }
    })

    //map.animateCamera(CameraUpdateFactory.newLatLngBounds(cameraAndViewport.melbourneBounds, 100), 2000, null)
    // map.setLatLngBoundsForCameraTarget(cameraAndViewport.melbourneBounds)
*/


// This would all go in the "map.uiSettings.apply {  } block

// This is from the last video I watched in the Google API tutorial
// Don't keep this!
// lifecycleScope.launch {
//     delay(4000L)
//     map.moveCamera(CameraUpdateFactory.scrollBy(-1000f, 300f))
// }

// I think I want some padding on the bottom for my buttons and other options
// Keeping this commented so I can come back to it
// map.setPadding(0, 0, 0, 300)