package com.example.forager

import androidx.fragment.app.Fragment

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import com.example.forager.fragments.FoundPlantFormFragment
import com.example.forager.oldcode.misc.TypeAndStyles
import com.example.forager.viewmodel.HomeViewModel

import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions

private const val LOG = "MapsFragment"

class MapsFragment : Fragment() {

    private val homeVM by viewModels<HomeViewModel>()
    private val typeAndStyles by lazy { TypeAndStyles() } // This is what I'm using for the style of my map!

    private val callback = OnMapReadyCallback { googleMap ->
        /**
         * Manipulates the map once available.
         * This callback is triggered when the map is ready to be used.
         * This is where we can add markers or lines, add listeners or move the camera.
         * In this case, we just add a marker near Sydney, Australia.
         * If Google Play services is not installed on the device, the user will be prompted to
         * install it inside the SupportMapFragment. This method will only be triggered once the
         * user has installed Google Play services and returned to the app.
         */
        googleMap.setPadding(0, 0, 0, 100)

//        toggleMarkerBtn.setOnCheckedChangeListener { compoundButton, toggled ->
//            homeVM.toggleMarkers(toggled)
//        }

        homeVM.getPlantsFoundMarkers.forEach { marker ->
            val pos = marker.position
            val title = marker.title
            googleMap.addMarker(MarkerOptions().position(pos).title(title))
        }

        // This does NOT work
        // I need to allow all of the user's found plants to be loaded onto the map when they log in
        // Right now it works, but only for the first 1-2 logins, after that all data is lost
        homeVM.getPersonalPlantListOfUsers.observe(this, { plantFoundList ->
            if(homeVM.getHasBeenToggled) {
                plantFoundList.forEach { plantNode ->
                    Log.i(LOG, plantNode.plantAdded.commonName)
                    val coord = LatLng(plantNode.lat, plantNode.long)
                    val marker = googleMap.addMarker(MarkerOptions().position(coord).title(plantNode.plantAdded.commonName))
                    homeVM.addMarker(marker!!)
                }
                homeVM.setHasBeenToggled(false)
            }
        })

        // Setting the styling of GoogleMap
        googleMap.uiSettings.apply {
            isZoomControlsEnabled = true
        }
        typeAndStyles.setMapStyle(googleMap, requireContext()) // Sets the style of my map using raw JSON

        // Possibly have a button that hides markers, or hides only some markers, etc.
        googleMap.setOnMapLongClickListener { latlng ->
            // This will use the navigation graph to navigate to the "found plants fragment"

        }

        // Add a marker in Sydney and move the camera
        val marquette = LatLng(46.5436, -87.3954)
        val newYork = LatLng(40.71614203933524, -74.0040676650565)
        googleMap.addMarker(MarkerOptions().position(marquette).title("Marquette Marker")) // assigning this marker to a variable so we can change the markers settings
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(marquette, 10f))
        //map.moveCamera(CameraUpdateFactory.newCameraPosition(cameraAndViewport.marquette))
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_maps, container, false)

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val mapFragment = childFragmentManager.findFragmentById(R.id.map) as SupportMapFragment?
        mapFragment?.getMapAsync(callback)
    }
}